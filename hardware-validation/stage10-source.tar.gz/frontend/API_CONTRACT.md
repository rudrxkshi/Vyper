# Frontend API Contract

This document is the handoff contract between the React frontend and the FastAPI backend.

## Authentication

If the backend enables API key enforcement, include:

- Header: `X-VYPER-API-Key`
- Value: the configured `VYPER_API_KEY`

## Base URL

The browser dashboard reads the backend base URL from
`NEXT_PUBLIC_VYPER_API_BASE_URL`, with a development fallback of
`http://127.0.0.1:8000`. The Settings screen can persist a runtime override in
browser local storage.

In local mode (`NEXT_PUBLIC_VYPER_MODE=local`), the default is
`http://127.0.0.1:8765` and may be set with
`NEXT_PUBLIC_VYPER_LOCAL_AGENT_API_BASE_URL`.

## Service split

- Central `GET /assets`: persisted inventory/history.
- Central `GET /devices`: backward-compatible persisted-assets alias, not live
  discovery.
- Local agent `GET /devices`: live read-only discovery for the local machine.
- Local agent health identifies itself with `service: "local-agent"` and
  `api_version: "2"`.

Local `POST /jobs/sanitize` returns `202 Accepted` with a `PENDING` job ID. Poll
`GET /jobs/{local_job_id}` for durable state, measured/indeterminate progress,
sequenced lifecycle events, and terminal evidence. `GET /jobs` returns local
history. Local responses use null for orchestration sections not yet available.

## Job submission

### `POST /jobs/sanitize`

Request body:

```json
{
  "target": "/dev/sdb",
  "authorization": {
    "approved": true,
    "ata_password": "optional"
  },
  "dry_run": false
}
```

Important behavior:

- `dry_run: true` must be treated as non-destructive planning.
- `authorization.approved` must be explicit for destructive operations.
- `ata_password` only applies to ATA secure erase flows.

## Read models

### Assets

On the central API, `GET /assets` and the compatibility `GET /devices` return
the same persisted storage inventory view.

The local agent `GET /devices` returns live records with `device_path`,
`device_type`, `model`, `serial_number`, `size_bytes`, `interface`, `transport`,
`rotational`, `mounted`, `mounted_partitions`, `is_system_device`,
`capabilities`, `warnings`, `profile_error`, and
`eligible_for_sanitization`.

Useful fields:

- `id`
- `asset_type`
- `device_path`
- `device_type`
- `model`
- `serial_number`
- `is_system_device`
- `mounted`
- `mounted_partitions`
- `profile_json`

### Jobs

`GET /jobs` returns job records with nested asset, result, certificate, and audit log data.

Fields to surface in the UI:

- `job_state`
- `final_status`
- `pathway`
- `outcome_kind`
- `successful_sanitization_claim`
- `dry_run`
- `message`
- `state_history_json`
- nested `asset`
- nested `result`
- nested `certificate`
- nested `audit_logs`

### Results

`GET /results` returns execution, verification, and evidence payloads.

Useful fields:

- `job_id`
- `started_at`
- `completed_at`
- `duration_seconds`
- `execution_json`
- `verification_json`
- `evidence_json`

### Certificates

`GET /certificates` returns certificate metadata and certificate JSON.

Useful fields:

- `certificate_id`
- `job_id`
- `target`
- `final_status`
- `outcome_kind`
- `successful_sanitization_claim`
- `certificate_hash`
- `certificate_json`

### Audit logs

`GET /audit-logs` returns request/response audit entries.

Useful fields:

- `action`
- `actor`
- `request_json`
- `response_json`
- `created_at`

## UI states

The frontend should handle these job states explicitly:

- `PENDING`
- `PROFILING`
- `POLICY_SELECTED`
- `AWAITING_AUTHORIZATION`
- `RUNNING`
- `VERIFYING`
- `VERIFIED`
- `FAILED`
- `INCONCLUSIVE`
- `UNSUPPORTED`
- `CANCELLED`

## Rendering guidance

- Show destructive actions behind a clear confirmation step.
- Prefer status badges for job state and final status.
- Render certificate and audit payloads in expandable JSON panels.
- Highlight system-associated assets as blocked from destructive actions.
- Separate `job_state` from `final_status` in the UI; they are related but not identical.

## Agent protocol v1

Operator routes use `X-VYPER-API-Key`. Agent synchronization routes use a
separate `Authorization: Bearer <agent-token>` credential and require
`agent_protocol_version: "1"` in typed payloads.

Enrollment and management:

- `POST /agents/enrollment-tokens`
- `POST /agents/enroll`
- `GET /agents`
- `POST /agents/{agent_id}/revoke`
- `GET /agents/{agent_id}/assets`
- `POST /agents/{agent_id}/jobs`
- `GET /central-jobs`

Outbound agent synchronization:

- `POST /agent/heartbeat`
- `PUT /agent/inventory`
- `GET /agent/jobs/next`
- `POST /agent/jobs/{central_job_id}/events`
- `POST /agent/jobs/{central_job_id}/result`

A central job creation body contains `asset_id`, `dry_run`,
`central_authorized`, `destructive_confirmation`, `idempotency_key`,
`expires_in_seconds`, and `execution_mode`. `execution_mode` is either
`normal_local` (the default) or `boot_sanitize`. The body does not accept a
free-form target or an ATA password. Destructive claims render as
`WAITING_LOCAL_APPROVAL` until the local console separately approves them.

The local console uses `GET /remote-jobs` and
`POST /remote-jobs/{central_job_id}/approve`. Its approval body contains
`approved` and an optional transient `ata_password`; the password is not
persisted or synchronized.

Lifecycle uploads to `POST /agent/jobs/{central_job_id}/events` contain
`agent_protocol_version`, `local_job_id`, a monotonically increasing
`sequence`, `state`, `timestamp`, `message`, and optional `progress`. Boot jobs
use the same typed event envelope and report boot-specific states such as
`BOOT_ENVIRONMENT_STARTED`; the central read model exposes `execution_mode`,
`boot_lifecycle`, and `local_execution_state` rather than inventing a separate
protocol.

## Release downloads

`GET /downloads` returns only artifacts that exist on disk and whose metadata
was generated by the release build. Each entry contains `version`, `platform`,
`architecture`, `filename`, `sha256`, `size_bytes`, `release_date`,
`download_url`, `minimum_agent_protocol`, and `minimum_local_api_version`.

`GET /downloads/{filename}` serves only the filename declared by the current
manifest. The public `/download/` page renders the available Linux x86_64
artifact and checksum. Windows and macOS are marked unavailable and have no
download targets.
